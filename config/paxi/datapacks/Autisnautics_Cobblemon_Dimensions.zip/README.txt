Autisnautics Cobblemon dimension ecology v1.0.0
See BUILD_REPORT.md and INSTALL.md beside the distribution ZIPs.
Main pack leaves Overworld and all non-stack dimensions unchanged.
Boss addon is optional, enables ultra-rare wild encounters, and requires the main pack.
Do not install both a folder and ZIP copy of the same pack.
